
export enum DellTag {
    Tag595B = "595B",
    TagD35B = "D35B",
    Tag2A7B = "2A7B",
    TagA95B = "A95B",
    Tag1D3B = "1D3B",
    Tag6FF1 = "6FF1",
    Tag1F66 = "1F66",
    Tag1F5A = "1F5A",
    TagBF97 = "BF97",
    TagE7A8 = "E7A8"
}

export const enum SuffixType {
    ServiceTag,
    HDD
}
